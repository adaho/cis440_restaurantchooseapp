[![Stories in Ready](https://badge.waffle.io/asu-cis-capstone/choosechew.png?label=ready&title=Ready)](https://waffle.io/asu-cis-capstone/choosechew)
# choosechew
repo for project ChooseChew

Team Members:
Jocelyn Ventura
Kelsey Coriell
Ada Ho

Our ChooseChew app is an app that aims to help hungry, indecisive users decide on a place to eat at. The app can randomly generate a nearby restaurant using the user's GPS location. The app will also have the option available for the user to login and create a Favorites list that will automatically be saved to the user's account. If the user so chooses, the app can also randomly select a restaurant only from his/her Favorites list. 

Measurement Plan:
% of users signs up for an account
% of users accepts a restaurant suggestion
% of users comes back and uses the app a second time

Baseline Measurement:
When we created a poll asking people whether they would be interested in using an app like ours or not, 8/8 = 100% said they would.
